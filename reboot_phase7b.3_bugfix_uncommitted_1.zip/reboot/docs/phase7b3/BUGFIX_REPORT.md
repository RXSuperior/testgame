# Phase 7B.3 bug fix and stabilization

Fixes for the code audit of tag `phase7b.3` (1 critical, 5 major, minor items). Only the side-view system, its data, its tests and the asset tool were changed.
Nothing is committed or tagged. The work waits for the independent review.

## Changed files
| File | Change |
|---|---|
| `src/sideview/sideview.js` | HP model, lifecycle, pause ownership, NPC events, combat rules, goblin physics, metadata validator |
| `src/ui/sv_view.js` | one click listener, inert background, key handling in dialogs, safe image drawing, tileset drawing, animation timing, all NPCs, touch layout |
| `src/ui/theme.css` | side-view block only: stage grid, touch pads outside the canvas, full-screen dialog layer |
| `data/worlds/hunter/areas.js` | `talkEvents` owned by an NPC, `sprite` on spawns |
| `data/assets/art_meta.js` | tileset cell map and sheet size, goblin animation list |
| `tools/assets.js` | sees asset references from areas, checks sprite and tileset sheet size |
| `tests/core.test.js` | 23 new regression tests, 2 old tests updated to the stricter behaviour |
| `tests/sv_smoke.py` | 39 new browser checks |
| `tests/fixtures/phase6_save.json` | new: real Phase 6 save |
| `docs/phase7b/ART_BIBLE.md`, `docs/phase7b3/*` | docs, regenerated asset inventory, screenshots |
| `dist/index.html` | rebuilt |

Not changed: `src/core`, `src/systems`, `src/ui/app.js`, other UI files, the save format, the combat contract, the mission validator. `git diff --stat -- src/core src/systems` is empty.

## Round 1

### 1. HP synchronization (critical)
- Cause: the runtime copied the player's HP when the area loaded and wrote that copy back through `combat.apply` on exit. Any HP change made by an event in the scene was undone, and a retreat report was sent although no fight happened.
- Fix: `player.hp` in GameState is the only source of truth. The runtime keeps one number, `dmg`: damage taken in the scene that has not been sent to `combat.apply` yet. `rt.hp` is a getter (`player.hp - dmg`) and `rt.maxHp` reads `player.maxHp()` every time.
- `settle()` sends a report only when `dmg > 0` and the player is alive. No damage means no `combat:done`.
- Tests: event damage survives exit with no `combat:done`; pending damage plus an outside HP change add up and settle once; level-up updates max HP; death in the scene changes nothing on exit.

### 2. Click listener (major)
- Cause: `#sv` was reused, but a click listener was added on every open.
- Fix: the element, its click listener and the key listeners are created once in `root()`. Touch listeners sit on buttons that are rebuilt on each open, so they cannot pile up.
- Tests (browser): third open, one click on save = one `saveTo`; one click on an answer = one `events.answer`, no error.

### 3. Pause and resume (major)
- Cause: `game:loaded` cleared the runtime reference, so the view never called `exit()` and the `explore` pause stayed. Keyboard focus could leave the overlay with Tab, which made this reachable.
- Fix: the handlers for `game:loaded` and `game:new` call `runtime.abort()`. It releases the runtime's own pause once and writes nothing (the state was just replaced). A runtime releases `explore` only if it is the registered active runtime; it never touches other reasons.
- Focus: `#app` is `inert` while the scene is open, and focus moves into the scene.
- Tests: load and new game during a scene leave no `explore` reason, keep `menu`, write nothing extra, and time can advance; an old runtime cannot release a new runtime's pause; 38 Tab presses never leave the scene.

### 4. NPC events (major)
- Cause: `talkEvents` belonged to the area, so every NPC offered Hajun's event and became its `who`.
- Fix: `talkEvents:[{npc,event}]`. The option shows only for that NPC. `choose()` re-checks that the NPC is in the scene and that the option belongs to them.
- Tests: only Hajun offers the event; choosing it through another NPC or an absent NPC throws; nobody offers it when Hajun is away.

### 5. Runtime lifecycle
- `enter()` refuses a second runtime. `open()` returns the running scene. `exit()` works once.
- A failed `enter()` releases its pause.
- Doors: the validator rejects a door to a location without an area or without the named arrival point. The runtime checks area and entry rule before it settles or moves. The old `left` path is gone, and so is the null access after it.
- The frame loop does not schedule a new frame after close. Tests count frame calls after close (0 new) and with a double open (one loop).

### 6. Gameplay rules
Old behaviour: fights cost no AP, ignored the heavy-injury rule that missions use, and gave 24 EXP a month for free.

New rule, in `fightWhy()` / `engage()`:
- A fight can start when the player is alive, has injury below 2 (same as missions) and has at least 1 AP.
- A fight starts when either side lands the first hit. Starting costs 1 AP per goblin, once.
- If a fight cannot start, goblins keep patrolling, cannot be damaged, cost nothing and give nothing. The HUD says why.
- Reward: only for a goblin whose fight was started (AP paid), once per spawn per month. Retreat or loss does not refund AP. After a loss all goblins disengage, so there is no loss loop.
- Goblins now use the same physics step as the player: solid blocks, platforms, world edges, gravity.

Open design question for the owner: a scene goblin gives 12 EXP for 1 AP. The mission against the same enemy gives 100 EXP, money and items for 1 AP. Reward size was not changed here because it is a balance decision.

## Round 2
1. Image load failure: the view draws real art only when the pipeline reports the file loaded, the image decoded, and the sheet is at least as large as the metadata needs. Otherwise it draws the placeholder. Drawing errors are reported once and do not stop the loop.
2. Placeholder fallback: tested with a missing file and with a sheet that is too small.
3. Tileset: drawn from the Asset Registry image using the `tiles` cell map (`top`, `fill`, `platform`), only for cells on screen.
4. Touch controls: pads are separate grid cells. Portrait: under the game image. Landscape: left and right of it. They never overlap the canvas (tested at 390x844, 360x740, 844x390).
5. HUD after level-up: fixed by item 1 of round 1.
6. Dialog keys: Space, Enter and Tab belong to the dialog buttons. E closes a result. A held E (key repeat) does not reopen the dialog.
7. NPC rendering: everyone at the location is placed. Owners of talk events get the designed spots first; the rest are spread over free positions away from doors. E picks the nearest NPC. Names show for all when 6 or fewer, otherwise only near the player.
8. Metadata: the runtime takes collision boxes from `bbox` and attack timing from the `attack` animation. The view uses `frame`, `anchor`, `anims` (row, frames, fps, loop). The validator rejects missing or inconsistent sprite and tileset metadata. The tool checks sheet size and lists area references.
9. `tests/fixtures/phase6_save.json`: made by running the code of tag `phase6` itself (mission bot, 150 months, rank B, level 35). Not edited by hand.

## Regression tests
Every new node test was also run against the old source (tag `phase7b.3`): 20 of 23 fail there. The 3 that pass check behaviour that was already correct (no fight = no report, save compatibility).

Node (`p7b3fix`, 23 tests): HP (5), pause (3), lifecycle (1), doors (1), NPC event (1), NPC crowd (1), combat rules (4), goblin collision (1), state writes (1), metadata (2), tool (1), saves (2).

Browser (39 checks): focus (2), listener (2), dialog keys (6), load and new game in scene (3), loop lifecycle (2), NPC crowd (1), wrong-size sheet (1), HUD and AP (3), missing sprite (2), real sprite (2), real tileset (1), error log (2), touch layout 3 screens x 4.

## Test results
| Suite | Result |
|---|---|
| `node tests/core.test.js` | 318 pass, 0 fail |
| `python3 tests/sv_smoke.py` | 75 pass, 0 fail |
| `python3 tests/smoke.py` x3 | 57/57 each |
| `python3 tests/ui_smoke.py` | 34/34 |
| `python3 tests/responsive.py` | 56/56 |
| `python3 tests/asset_smoke.py` | 11/11 |
| `node tools/assets.js --check` | 100 assets, 0 errors, 0 warnings |

Build: `python3 tools/build.py` → `dist/index.html`, 60 files, syntax check passed.

## Save compatibility
Fixtures Phase 2, 3, 4, 5 and 6 each: load; every old slice equals a build without side-view; `scene` gets its default; save again and reload is byte-identical; six more months of play stay identical with and without side-view. The Phase 6 save also enters the gate zone, fights, saves and reloads. The save format did not change.

## Performance
- Node: 16 µs per step with two goblins using full physics (was 4 µs without goblin collision); 2.8 µs per step with 205 NPCs in the area.
- Browser: 0.22 ms per frame on average including drawing.
- GameState writes during frames: none. The only write in a fight before it ends is the single AP payment when it starts (tested over 600 frames).

## Known limits
- Reward size versus AP cost (see round 1, item 6).
- The enemy is the existing `goblins` entry, whose name is "ฝูงก็อบลิน" (a pack). One sprite stands for it.
- Goblins do not jump. A goblin pushed outside its patrol range behind a block walks into the block until the player comes near.
- Landscape phones narrower than about 600 px get a small game image because the pads take 144 px.
- Real touch hardware, Firefox and Safari were not tested. `inert` needs Chrome 102, Safari 15.5 or Firefox 112.
